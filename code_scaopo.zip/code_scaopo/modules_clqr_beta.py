import numpy as np
import torch
import cvxpy as cp
import torch.nn as nn
import torch.nn.functional as F


class BetaPolicy(nn.Module):
    # beta distribution: f( (x+h)/2h, a, b)
    # action space bound: [-h, h]
    def __init__(self, state_dim, fc1_dim, fc2_dim, action_dim, device, T):
        super(BetaPolicy, self).__init__()
        self.net = MLP(state_dim, fc1_dim, fc2_dim, 2 * action_dim, device)
        self.action_dim = action_dim
        self.h = 5 * torch.ones(self.action_dim, dtype=torch.float, device=device)
        self.T = T
        self.device = device
        self.to(self.device)

    def forward(self, state, action):
        raise NotImplementedError

    def evaluate_action(self, state_torch, action_torch):
        self.net.train()
        a_b_values = self.net(state_torch)
        a = a_b_values[:, 0:self.action_dim]
        b = a_b_values[:, self.action_dim:]
        beta_ = torch.distributions.beta.Beta(a, b)
        h = self.h.view(1, -1).repeat(self.T, 1)
        log_prob_action = beta_.log_prob((action_torch + h) / (2 * h)).sum(dim=1)

        return log_prob_action

    def sample_action(self, state):
        self.net.eval()
        state_torch = torch.tensor(state, dtype=torch.float, device=self.device)
        with torch.no_grad():
            a_b_values = self.net(state_torch)
            a = a_b_values[0:self.action_dim]
            b = a_b_values[self.action_dim:]
            beta_ = torch.distributions.beta.Beta(a, b)
            action = beta_.sample() * (2 * self.h) - self.h

        return action.detach().cpu().numpy()


class MLP(nn.Module):
    def __init__(self, state_dim, fc1_dim, fc2_dim, action_dim, device):
        super(MLP, self).__init__()
        self.input_dim = state_dim
        self.fc1_dim = fc1_dim
        self.fc2_dim = fc2_dim
        self.action_dim = action_dim

        self.fc1 = nn.Linear(self.input_dim, self.fc1_dim)
        nn.init.orthogonal_(self.fc1.weight.data, gain=np.sqrt(2))
        nn.init.constant_(self.fc1.bias.data, 0.0)

        self.fc2 = nn.Linear(self.fc1_dim, self.fc2_dim)
        nn.init.orthogonal_(self.fc2.weight.data, gain=np.sqrt(2))
        nn.init.constant_(self.fc2.bias.data, 0.0)

        self.fc3 = nn.Linear(self.fc2_dim, self.action_dim)
        nn.init.orthogonal_(self.fc3.weight.data, gain=np.sqrt(2))
        nn.init.constant_(self.fc3.bias.data, 0.0)
        self.device = device
        self.to(self.device)

    def forward(self, state):
        x = self.fc1(state)
        x = torch.tanh(x)
        x = self.fc2(x)
        x = torch.tanh(x)
        a_b_values = self.fc3(x)
        a_b_values = F.softplus(a_b_values) + 1

        return a_b_values


class DataStorage(object):
    def __init__(self, T, num_new_data, state_dim, action_dim, constraint_dim):
        self.T = T
        self.num_new_data = num_new_data
        self.count = 0
        self.state_memory = np.zeros((2 * self.T, state_dim))
        self.action_memory = np.zeros((2 * self.T, action_dim))
        self.cost_memory = np.zeros((2 * self.T, 1+constraint_dim))
        self.n_entries = 0
        self.state_memory_tmp = np.zeros((num_new_data, state_dim))
        self.action_memory_tmp = np.zeros((num_new_data, action_dim))
        self.cost_memory_tmp = np.zeros((num_new_data, 1+constraint_dim))

    def store_experiences(self, state, action, costs):
        if self.count < 2 * self.T:
            self.state_memory[self.count] = state
            self.action_memory[self.count] = action
            self.cost_memory[self.count] = costs
            self.count += 1
        else:
            ind = self.count % self.num_new_data
            self.state_memory_tmp[ind] = state
            self.action_memory_tmp[ind] = action
            self.cost_memory_tmp[ind] = costs
            if ind == self.num_new_data-1:
                self.state_memory[0: 2 * self.T - self.num_new_data] = self.state_memory[self.num_new_data:]
                self.state_memory[2 * self.T - self.num_new_data:] = self.state_memory_tmp
                self.action_memory[0: 2 * self.T - self.num_new_data] = self.action_memory[self.num_new_data:]
                self.action_memory[2 * self.T - self.num_new_data:] = self.action_memory_tmp
                self.cost_memory[0: 2 * self.T - self.num_new_data] = self.cost_memory[self.num_new_data:]
                self.cost_memory[2 * self.T - self.num_new_data:] = self.cost_memory_tmp
            self.count += 1

        if self.n_entries < 2 * self.T:
            self.n_entries += 1

    def take_experiences(self):

        return self.state_memory, self.action_memory, self.cost_memory


def update_policy(func_value_np, grad_np, paras_t_np, tau_reward, tau_cost):
    x, paras_bar, prob_status_fea = _feasible_update(func_value_np, grad_np, paras_t_np, tau_cost)
    if x == np.inf:
        print('feasible problem break ! status = ', prob_status_fea)

    if x <= 0:
        paras_bar, prob_status_obj = _objective_update(func_value_np, grad_np, paras_t_np,
                                                       tau_reward=tau_reward, tau_cost=tau_cost)
        if paras_bar is None:
            print('objective problem break ! status = ', prob_status_obj)

    return paras_bar


def _objective_update(func_value_np, grad_np, paras_t_np, tau_reward, tau_cost):
    m = grad_np.shape[0] - 1  # number of constraints.
    n = grad_np.shape[1]  # dim of parameter.
    tau_np = tau_cost * np.ones(m + 1)
    tau_np[0] = tau_reward

    paras_cvx = cp.Variable(shape=(n,))
    obj = func_value_np[0] + grad_np[0].T @ (paras_cvx - paras_t_np) + \
          tau_np[0] * cp.sum_squares(paras_cvx - paras_t_np)
    constr = []
    for i in range(1, m + 1):
        constr += [func_value_np[i] + grad_np[i].T @ (paras_cvx - paras_t_np) +
                   tau_np[i] * cp.sum_squares(paras_cvx - paras_t_np) <= 0]
    prob = cp.Problem(cp.Minimize(obj), constr)
    prob.solve(solver=cp.MOSEK)
    paras_mosek = paras_cvx.value

    return paras_mosek, prob.status


def _feasible_update(func_value_np, grad_np, paras_t_np, tau_cost):
    m = grad_np.shape[0] - 1  # number of constraints.
    n = grad_np.shape[1]  # dim of parameter.
    func_value_np = func_value_np[1:]
    grad_np = grad_np[1:]
    tau_np = tau_cost * np.ones(m)

    paras_cvx = cp.Variable(shape=(n,))
    x_cvx = cp.Variable()
    obj = x_cvx
    constr = []
    for i in range(m):
        constr += [func_value_np[i] + grad_np[i].T @ (paras_cvx - paras_t_np) +
                   tau_np[i] * cp.sum_squares(paras_cvx - paras_t_np) <= x_cvx]
    prob = cp.Problem(cp.Minimize(obj), constr)
    prob.solve(solver=cp.MOSEK)
    x_mosek = prob.value
    paras_mosek = paras_cvx.value

    return x_mosek, paras_mosek, prob.status


class Environment(object):
    def __init__(self, seed, state_dim, action_dim):
        super(Environment, self).__init__()
        self.seed = seed
        self.seed_step = seed
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.s = np.zeros(state_dim)
        self.A = np.zeros((state_dim, state_dim))
        self.B = np.zeros((state_dim, action_dim))
        self.Q1 = np.zeros((state_dim, state_dim))
        self.R1 = np.zeros((action_dim, action_dim))
        self.Q2 = np.zeros((state_dim, state_dim))
        self.R2 = np.zeros((action_dim, action_dim))
        self.noise_mu = 1
        self.noise_std = 0.9

    def reset(self):
        # Reset the environment and return the initial state.
        np.random.seed(self.seed)
        self.A = np.random.randn(self.state_dim, self.state_dim)
        self.A = (self.A + self.A.T) / 30
        self.B = np.random.randn(self.state_dim, self.action_dim) / 3
        eig_values = np.random.rand(self.state_dim)
        S = np.diag(eig_values)
        U = self.generate_ortho_mat(dim=self.state_dim)
        self.Q1 = U @ S @ (U.T)
        E1 = np.random.randn(self.action_dim, self.action_dim)
        self.R1 = E1 @ (E1.T)
        np.random.seed(self.seed + 1996)
        C2 = np.random.exponential(1/3, size=(self.state_dim, self.state_dim))
        self.Q2 = C2 @ (C2.T)
        eig_values = np.random.rand(self.action_dim)
        S = np.diag(eig_values)
        U = self.generate_ortho_mat(dim=self.action_dim)
        self.R2 = U @ S @ (U.T)
        self.R2 = self.R2 @ (self.R2.T)

        self.s = np.random.randn(self.state_dim)

        return self.s

    def step(self, a):
        # return the next_state, reward, done = False, info.
        np.random.seed(self.seed_step)
        self.seed_step += 1
        a = a.reshape(-1)
        r = self.s.T @ self.Q1 @ self.s + a.T @ self.R1 @ a
        c = self.s.T @ self.Q2 @ self.s + a.T @ self.R2 @ a
        d = False
        info = {'cost': c}
        self.s = self.A @ self.s + self.B @ a + (self.noise_mu + self.noise_std * np.random.randn(self.state_dim))

        return self.s, r, d, info

    def generate_ortho_mat(self, dim):
        random_state = np.random
        H = np.eye(dim)
        D = np.ones((dim,))
        for n in range(1, dim):
            x = random_state.normal(size=(dim - n + 1,))
            D[n - 1] = np.sign(x[0])
            x[0] -= D[n - 1] * np.sqrt((x * x).sum())
            # Householder transformation
            Hx = (np.eye(dim - n + 1) - 2. * np.outer(x, x) / (x * x).sum())
            mat = np.eye(dim)
            mat[n - 1:, n - 1:] = Hx
            H = np.dot(H, mat)
            # Fix the last sign such that the determinant is 1
        D[-1] = (-1) ** (1 - (dim % 2)) * D.prod()
        # Equivalent to np.dot(np.diag(D), H) but faster, apparently
        H = (D * H.T).T
        return H

