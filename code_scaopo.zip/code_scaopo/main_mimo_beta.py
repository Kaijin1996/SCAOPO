import torch
import numpy as np
import os
from modules_mimo_beta import Environment
from modules_mimo_beta import BetaPolicy
from modules_mimo_beta import DataStorage
from modules_mimo_beta import update_policy
import matplotlib.pyplot as plt
"""Code of MU-MIMO in example 1 by using the Beta policy. """


if __name__ == "__main__":
    seed = 0
    np.random.seed(seed)
    torch.manual_seed(seed)

    # Parameters
    Nt, UE_num, user_per_group = 8, 4, 2
    state_dim = 2 * UE_num * Nt + UE_num
    action_dim = UE_num + 1
    env = Environment(seed=seed, Nt=Nt, UE_num=UE_num, user_per_group=user_per_group)

    T = 1500
    num_new_data = 1000  # the number of newly added experiences after each update.
    fc1_dim, fc2_dim = 128, 128  # hidden sizes of policy network.
    device = "cuda:0"
    constraint_dim = UE_num
    constr_lim = np.array([1.0, 1.4, 1.0, 1.4])
    tau_reward = 0.35  # the regularization constant in the surrogate function.
    tau_cost = 0.35
    interaction_steps = 0
    num_steps = int(1e6)

    chkpt_dir = 'mimo_beta'
    if not os.path.exists(chkpt_dir):
        os.makedirs(chkpt_dir)

    chkpt_dir_data = chkpt_dir + '/saved_data'
    if not os.path.exists(chkpt_dir_data):
        os.makedirs(chkpt_dir_data)

    chkpt_dir_model = chkpt_dir + '/saved_model'
    if not os.path.exists(chkpt_dir_model):
        os.makedirs(chkpt_dir_model)

    # Initialization
    actor = BetaPolicy(state_dim, fc1_dim, fc2_dim, action_dim, device, T)
    theta_dim = 0
    for para in actor.net.parameters():
        theta_dim += para.numel()
    paras_torch = torch.zeros((theta_dim,), dtype=torch.float, device=device)
    ind = 0
    for para in actor.net.parameters():
        tmp = para.numel()
        paras_torch[ind: ind + tmp] = para.data.view(-1)
        ind = ind + tmp
    func_value = np.zeros(constraint_dim + 1)
    grad = np.zeros((constraint_dim + 1, theta_dim))

    buffer = DataStorage(T, num_new_data, state_dim, action_dim, constraint_dim)
    t_update = 0  # the number of updating policy
    model_saved_count = 0
    reward_rate_all = []
    cost_rate_all = []
    reward_sum = 0
    cost_sum_total = 0
    observation = env.reset()
    for step in range(num_steps):
        # generate new data
        state = observation
        action = actor.sample_action(state)
        observation, reward, done, info = env.step(action)  # reward is the power cost in mu-mimo.
        costs = np.zeros(constraint_dim + 1)
        costs[0] = reward
        for k in range(1, constraint_dim + 1):
            costs[k] = info.get('cost_' + str(k), 0) - constr_lim[k-1]
        buffer.store_experiences(state, action, costs)
        interaction_steps += 1
        reward_sum += reward
        cost_sum_total += info.get('cost', 0)

        if (step+1) % 3000 == 0:
            reward_rate_all.append(reward_sum / interaction_steps)
            cost_rate_all.append(cost_sum_total / interaction_steps)
            print('step: %d, reward_rate = %.3f, avg_cost_rate = %.3f' % (step, reward_sum / interaction_steps
                                                                         ,cost_sum_total / interaction_steps / UE_num))
            np.save(chkpt_dir_data + '/reward_rate_all.npy', np.array(reward_rate_all))
            np.save(chkpt_dir_data + '/cost_rate_all.npy', np.array(cost_rate_all))

        if (interaction_steps % num_new_data == 0) and (buffer.n_entries == 2 * T):
            # estimate value
            t_update += 1
            alpha = 1 / (t_update ** 0.6)
            beta = 1 / (t_update ** 0.9)
            state_batch, action_batch, costs_batch = buffer.take_experiences()
            func_value_tilda = np.mean(costs_batch, axis=0)
            func_value = (1 - alpha) * func_value + alpha * func_value_tilda

            Q_hat = np.zeros((T, 1 + constraint_dim))
            for _ in range(1, T + 1):
                costs_tmp = costs_batch[_: _ + T]
                Q_hat[_ - 1] = np.sum(costs_tmp, axis=0) - T * func_value

            Q_hat[:, 0] = (Q_hat[:, 0] - np.mean(Q_hat[:, 0])) / (np.std(Q_hat[:, 0]) + 1e-6)
            for _ in range(1, 1 + constraint_dim):
                Q_hat[:, _] = Q_hat[:, _] - np.mean(Q_hat[:, _])

            Q_hat_torch = torch.tensor(Q_hat, dtype=torch.float, device=device)

            state_batch_torch = torch.tensor(state_batch[1:T + 1], dtype=torch.float, device=device)
            action_batch_torch = torch.tensor(action_batch[1:T + 1], dtype=torch.float, device=device)
            grad_tilda_torch = torch.zeros((1 + constraint_dim, theta_dim), dtype=torch.float, device=device)
            for _ in range(1 + constraint_dim):
                actor.zero_grad()
                log_prob = actor.evaluate_action(state_batch_torch, action_batch_torch)
                actor_loss = (Q_hat_torch[:, _] * log_prob).mean()
                actor_loss.backward()
                grad_tmp = torch.zeros(theta_dim, dtype=torch.float, device=device)
                ind = 0
                for para in actor.net.parameters():
                    tmp = para.numel()
                    grad_tmp[ind: ind + tmp] = para.grad.view(-1)
                    ind = ind + tmp
                grad_tilda_torch[_] = grad_tmp
            grad = (1 - alpha) * grad + alpha * grad_tilda_torch.detach().cpu().numpy()

            # update
            paras_bar = update_policy(func_value, grad, paras_torch.detach().cpu().numpy(),
                                      tau_reward=tau_reward, tau_cost=tau_cost)
            paras_bar_torch = torch.tensor(paras_bar, dtype=torch.float, device=device)
            paras_torch = (1 - beta) * paras_torch + beta * paras_bar_torch
            ind = 0
            for para in actor.net.parameters():
                tmp = para.numel()
                para.data = paras_torch[ind: ind + tmp].view(para.shape)
                ind = ind + tmp

        if (step+1) % 10000 == 0:
            checkpoint_file = os.path.join(chkpt_dir_model, 'Actor' + str(model_saved_count))
            torch.save(actor.net.state_dict(), checkpoint_file)
            model_saved_count += 1

    epoc = np.linspace(0, len(reward_rate_all)-1, len(reward_rate_all))
    reward_rate_all = np.array(reward_rate_all)
    plt.figure()
    plt.plot(epoc, reward_rate_all, label=r'$T = 1500, new = 1000$')
    plt.xlabel('Epoch', fontsize=12, fontweight='roman')
    plt.ylabel('Power consumption (W)', fontsize=12, fontweight='roman')
    plt.title('MIMO using the Beta policy')
    plt.legend(loc=1)
    plt.show()

    cost_limit = np.ones(epoc.shape[0]) * constr_lim.mean()
    cost_rate_all = np.array(cost_rate_all)
    cost_rate_all = cost_rate_all / UE_num
    plt.figure()
    plt.plot(epoc, cost_rate_all, label=r'$T = 1500, new = 1000$')
    plt.plot(epoc, cost_limit, 'k:', linewidth=1.5)
    plt.xlabel('Epoch', fontsize=12, fontweight='roman')
    plt.ylabel('Average delay per user (ms)', fontsize=12, fontweight='roman')
    plt.title('MIMO using the Beta policy')
    plt.legend(loc=1)
    plt.show()