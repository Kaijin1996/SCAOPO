import numpy as np
import torch
import cvxpy as cp
import torch.nn as nn
import torch.nn.functional as F


class GaussianPolicy(nn.Module):
    def __init__(self, state_dim, fc1_dim, fc2_dim, action_dim, device, T):
        super(GaussianPolicy, self).__init__()
        self.net = MLP(state_dim, fc1_dim, fc2_dim, action_dim, device)
        self.log_std = -0.5 * torch.ones(action_dim, dtype=torch.float, device=device)
        self.action_dim = action_dim
        self.T = T
        self.device = device
        self.to(self.device)

    def forward(self, state, action):
        raise NotImplementedError

    def evaluate_action(self, state_torch, action_torch):
        self.net.train()
        mu = self.net(state_torch)
        self.log_std.requires_grad = True
        self.std_eval = torch.exp(self.log_std)
        self.std_eval = self.std_eval.view(1, -1).repeat(self.T, 1)
        gaussian_ = torch.distributions.normal.Normal(mu, self.std_eval)
        log_prob_action = gaussian_.log_prob(action_torch).sum(dim=1)

        return log_prob_action

    def sample_action(self, state):
        self.net.eval()
        self.log_std.requires_grad = False
        state_torch = torch.tensor(state, dtype=torch.float, device=self.device)
        with torch.no_grad():
            mu = self.net(state_torch)
            self.std_sample = torch.exp(self.log_std)
            gaussian_ = torch.distributions.normal.Normal(mu, self.std_sample)
            action = gaussian_.sample()

        return action.detach().cpu().numpy()


class MLP(nn.Module):
    def __init__(self, state_dim, fc1_dim, fc2_dim, action_dim, device):
        super(MLP, self).__init__()
        self.input_dim = state_dim
        self.fc1_dim = fc1_dim
        self.fc2_dim = fc2_dim
        self.action_dim = action_dim

        self.fc1 = nn.Linear(self.input_dim, self.fc1_dim)
        nn.init.orthogonal_(self.fc1.weight.data, gain=np.sqrt(2))
        nn.init.constant_(self.fc1.bias.data, 0.0)

        self.fc2 = nn.Linear(self.fc1_dim, self.fc2_dim)
        nn.init.orthogonal_(self.fc2.weight.data, gain=np.sqrt(2))
        nn.init.constant_(self.fc2.bias.data, 0.0)

        self.fc3 = nn.Linear(self.fc2_dim, self.action_dim)
        nn.init.orthogonal_(self.fc3.weight.data, gain=np.sqrt(2))
        nn.init.constant_(self.fc3.bias.data, 0.0)
        self.device = device
        self.to(self.device)

    def forward(self, state):
        x = self.fc1(state)
        x = torch.tanh(x)
        x = self.fc2(x)
        x = torch.tanh(x)
        mu = self.fc3(x)
        mu = 2.5 * torch.sigmoid(mu)

        return mu


class DataStorage(object):
    def __init__(self, T, num_new_data, state_dim, action_dim, constraint_dim):
        self.T = T
        self.num_new_data = num_new_data
        self.count = 0
        self.state_memory = np.zeros((2 * self.T, state_dim))
        self.action_memory = np.zeros((2 * self.T, action_dim))
        self.cost_memory = np.zeros((2 * self.T, 1+constraint_dim))
        self.n_entries = 0
        self.state_memory_tmp = np.zeros((num_new_data, state_dim))
        self.action_memory_tmp = np.zeros((num_new_data, action_dim))
        self.cost_memory_tmp = np.zeros((num_new_data, 1+constraint_dim))

    def store_experiences(self, state, action, costs):
        if self.count < 2 * self.T:
            self.state_memory[self.count] = state
            self.action_memory[self.count] = action
            self.cost_memory[self.count] = costs
            self.count += 1
        else:
            ind = self.count % self.num_new_data
            self.state_memory_tmp[ind] = state
            self.action_memory_tmp[ind] = action
            self.cost_memory_tmp[ind] = costs
            if ind == self.num_new_data-1:
                self.state_memory[0: 2 * self.T - self.num_new_data] = self.state_memory[self.num_new_data:]
                self.state_memory[2 * self.T - self.num_new_data:] = self.state_memory_tmp
                self.action_memory[0: 2 * self.T - self.num_new_data] = self.action_memory[self.num_new_data:]
                self.action_memory[2 * self.T - self.num_new_data:] = self.action_memory_tmp
                self.cost_memory[0: 2 * self.T - self.num_new_data] = self.cost_memory[self.num_new_data:]
                self.cost_memory[2 * self.T - self.num_new_data:] = self.cost_memory_tmp
            self.count += 1

        if self.n_entries < 2 * self.T:
            self.n_entries += 1

    def take_experiences(self):

        return self.state_memory, self.action_memory, self.cost_memory


def update_policy(func_value_np, grad_np, paras_t_np, tau_reward, tau_cost):
    x, paras_bar, prob_status_fea = _feasible_update(func_value_np, grad_np, paras_t_np, tau_cost)
    if x == np.inf:
        print('feasible problem break ! status = ', prob_status_fea)

    if x <= 0:
        paras_bar, prob_status_obj = _objective_update(func_value_np, grad_np, paras_t_np,
                                                       tau_reward=tau_reward, tau_cost=tau_cost)
        if paras_bar is None:
            print('objective problem break ! status = ', prob_status_obj)

    return paras_bar


def _objective_update(func_value_np, grad_np, paras_t_np, tau_reward, tau_cost):
    m = grad_np.shape[0] - 1  # number of constraints.
    n = grad_np.shape[1]  # dim of parameter.
    tau_np = tau_cost * np.ones(m + 1)
    tau_np[0] = tau_reward

    paras_cvx = cp.Variable(shape=(n,))
    obj = func_value_np[0] + grad_np[0].T @ (paras_cvx - paras_t_np) + \
          tau_np[0] * cp.sum_squares(paras_cvx - paras_t_np)
    constr = []
    for i in range(1, m + 1):
        constr += [func_value_np[i] + grad_np[i].T @ (paras_cvx - paras_t_np) +
                   tau_np[i] * cp.sum_squares(paras_cvx - paras_t_np) <= 0]
    prob = cp.Problem(cp.Minimize(obj), constr)
    prob.solve(solver=cp.MOSEK)
    paras_mosek = paras_cvx.value

    return paras_mosek, prob.status


def _feasible_update(func_value_np, grad_np, paras_t_np, tau_cost):
    m = grad_np.shape[0] - 1  # number of constraints.
    n = grad_np.shape[1]  # dim of parameter.
    func_value_np = func_value_np[1:]
    grad_np = grad_np[1:]
    tau_np = tau_cost * np.ones(m)

    paras_cvx = cp.Variable(shape=(n,))
    x_cvx = cp.Variable()
    obj = x_cvx
    constr = []
    for i in range(m):
        constr += [func_value_np[i] + grad_np[i].T @ (paras_cvx - paras_t_np) +
                   tau_np[i] * cp.sum_squares(paras_cvx - paras_t_np) <= x_cvx]
    prob = cp.Problem(cp.Minimize(obj), constr)
    prob.solve(solver=cp.MOSEK)
    x_mosek = prob.value
    paras_mosek = paras_cvx.value

    return x_mosek, paras_mosek, prob.status


class Environment(object):
    def __init__(self, seed, Nt, UE_num, user_per_group):
        super(Environment, self).__init__()
        self.seed = seed
        self.seed_step = seed
        self.Nt = Nt
        self.UE_num = UE_num
        self.user_per_group = user_per_group
        self.group_num = int(UE_num / user_per_group)
        self.state_dim = 2 * UE_num * Nt + UE_num
        self.action_dim = UE_num + 1
        self.Np = 4

        np.random.seed(seed)
        PathGain_dB = np.random.uniform(-10, 10, self.group_num)
        self.PathGain = 10 ** (PathGain_dB / 10)
        alpha_power_group = np.zeros((self.group_num, self.Np))
        for group in range(self.group_num):
            tmp = np.random.exponential(scale=1, size=self.Np)
            alpha_power_group[group] = (tmp * self.PathGain[group]) / np.sum(tmp)
        self.alpha_power = np.tile(alpha_power_group, (self.user_per_group, 1))

        array_reponse_group = np.zeros((self.group_num * self.Nt, self.Np)) + \
                              1j * np.zeros((self.group_num * self.Nt, self.Np))
        for group in range(self.group_num):
            A_tmp = np.zeros((self.Nt, self.Np)) + 1j * np.zeros((self.Nt, self.Np))
            for i in range(self.Np):
                AoD = self.laprnd(mu=0, angular_spread=5)
                A_tmp[:, i] = np.exp(1j * np.pi * np.sin(AoD) * np.arange(0, self.Nt))
            array_reponse_group[group * self.Nt: (group+1) * self.Nt] = A_tmp
        self.array_response = np.tile(array_reponse_group, (self.user_per_group, 1))

        self.H_g = np.zeros((self.group_num, Nt)) + 1j * np.zeros((self.group_num, Nt))
        self.H = np.zeros((UE_num, Nt)) + 1j * np.zeros((UE_num, Nt))
        self.D = np.zeros(UE_num)
        self.state = np.zeros(self.state_dim)
        self.noise_power = 1e-6
        self.Dmax = 5

    def reset(self):
        # Reset the environment and return the initial state.
        np.random.seed(self.seed)
        for g in range(self.group_num):
            alpha_power_g = self.alpha_power[g]
            A_g = self.array_response[g * self.Nt: (g + 1) * self.Nt]
            alpha_g = np.sqrt(alpha_power_g / 2) * np.random.randn(self.Np) + \
                      1j * np.sqrt(alpha_power_g / 2) * np.random.randn(self.Np)
            self.H_g[g] = A_g @ alpha_g
        self.H = np.repeat(self.H_g, self.user_per_group, axis=0)
        self.D = np.zeros(self.UE_num)
        h_real = np.real(self.H)
        h_real = h_real.reshape(-1)
        h_imag = np.imag(self.H)
        h_imag = h_imag.reshape(-1)
        self.state = np.hstack((h_real, h_imag, self.D))

        return self.state

    def step(self, action):
        # action contains power allocation and regularization factor.
        # return the next_state, reward, done = False, info.
        np.random.seed(self.seed_step)
        self.seed_step += 1
        action = action.reshape(-1)
        action[action <= 0] = 1e-6
        power = action[0: self.UE_num]
        reg_factor = action[self.UE_num]

        reward = np.sum(power)
        costs = self.D
        info = {'cost_' + str(i): costs[i - 1] for i in range(1, self.UE_num + 1)}
        info['cost'] = np.sum(costs)

        try:
            V = self.H.conjugate().T @ np.linalg.inv(self.H @ self.H.conjugate().T + reg_factor * np.eye(self.UE_num))
        except:
            V = self.H.conjugate().T @ np.linalg.pinv(self.H @ self.H.conjugate().T + reg_factor * np.eye(self.UE_num))

        norm_vector = np.zeros(self.UE_num)
        for k in range(self.UE_num):
            norm_vector[k] = 1 / (np.linalg.norm(V[:, k]) + 1e-7)
        V_tilda = V @ np.diag(norm_vector)

        hv_tilda = self.H @ V_tilda
        r_d = np.zeros(self.UE_num)
        for k in range(self.UE_num):
            module_squ = np.abs(hv_tilda[k]) ** 2
            numerator = power[k] * module_squ[k]
            module_squ[k] = 0
            dominator = np.sum(power * module_squ) + self.noise_power
            r_d[k] = np.log2(1 + numerator / dominator)
        A_d = np.random.uniform(0, 2, self.UE_num)
        self.D = self.D + A_d - r_d
        self.D[self.D <= 0] = 0.0
        self.D[self.D >= self.Dmax] = self.Dmax
        for g in range(self.group_num):
            alpha_power_g = self.alpha_power[g]
            A_g = self.array_response[g * self.Nt: (g + 1) * self.Nt]
            alpha_g = np.sqrt(alpha_power_g / 2) * np.random.randn(self.Np) + \
                      1j * np.sqrt(alpha_power_g / 2) * np.random.randn(self.Np)
            self.H_g[g] = A_g @ alpha_g
        self.H = np.repeat(self.H_g, self.user_per_group, axis=0)
        h_real = np.real(self.H)
        h_real = h_real.reshape(-1)
        h_imag = np.imag(self.H)
        h_imag = h_imag.reshape(-1)
        self.state = np.hstack((h_real, h_imag, self.D))
        d = False

        return self.state, reward, d, info

    def laprnd(self, mu, angular_spread):
        b = angular_spread / np.sqrt(2)
        a = np.random.rand(1) - 0.5
        x = mu - b * np.sign(a) * np.log(1 - 2 * np.abs(a))

        return x




